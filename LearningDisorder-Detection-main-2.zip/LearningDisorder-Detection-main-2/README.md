# LearningDisorder-Detection
A website that Integrates Machine learning to predict whether a child has dyslexia or dyscalculia based upon a survey and quiz.
